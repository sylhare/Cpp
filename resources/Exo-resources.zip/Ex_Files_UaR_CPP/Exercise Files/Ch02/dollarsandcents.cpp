/*
 * dollarsandcents.cpp
 *
 *  Created on: May 13, 2014
 *      Author: Peggy Fisher
 */

#include <iostream>
using namespace std;
int main()
{
	
}
